# ssbc
手撕包菜网站

## 网站说明
这是手撕包菜搜索引擎的网站源代码。
开源的目的是为了促进技术交流和相互学习，把DHT与搜索引擎技术应用到更广泛的领域去。

本站于2015年5月使用django改写。
与爬虫相关的代码都在目录workers下。

相关文章请查看作者博客：
http://xiaoxia.org/2015/05/15/shousibaocai-opensource/
